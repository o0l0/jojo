package chapter40;

import java.io.*;
import java.util.*;
import java.sql.*;

public class Exercise40_6  {
  PreparedStatement pstmtGetResult;
    Connection conn;

  public Exercise40_6() {
    initializeJdbc();
  }

  /**Initialize database connection*/
  private void initializeJdbc() {
    try {
      // Declare driver and connection string
//      String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
//      String connectionString = "jdbc:odbc:exampleMDBDataSource";
      // For Oracle
	 // Load the JDBC driver
	 Class.forName("com.mysql.jdbc.Driver");
	 System.out.println("Driver loaded");
	
	 // Establish a connection
	 Connection conn = DriverManager.getConnection
	   ("jdbc:mysql://localhost/javabook" , "scott", "tiger");
	 System.out.println("Database connected");

         pstmtGetResult = conn.prepareStatement
        ("select name, score from csci4990 where ssn = ?");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public String[] getNameScore(String ssn, String table) {
    try {
      Statement statement = conn.createStatement();
      ResultSet rs = statement.executeQuery("select name, score from "
              + table + " where ssn = '" + ssn + "'");

      if (rs == null)
        return null;
      else {
        while (rs.next()) {
          String[] result = new String[2];
          result[0] = rs.getString(1);
          result[1] = Double.toString(rs.getDouble(2));
          return result;
        }
        return null;
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
      return null;
    }
  }
}
