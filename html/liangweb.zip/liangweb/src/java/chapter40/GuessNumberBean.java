package chapter40;

public class GuessNumberBean {
  private int number; // Entered from the form by the user
  private int target = 0;
  
  public GuessNumberBean() {
    target = (int)(Math.random() * 1000 + 1);
  }
  
  public int getNumber() {
    return number;
  }
  
  public void setNumber(int number) {
    this.number = number;
  }
  
  public String guess() {
    if (number < target)
      return "Too low";
    else if (number > target)
      return "Too high";
    else 
      return "You got it!";
  }
}
